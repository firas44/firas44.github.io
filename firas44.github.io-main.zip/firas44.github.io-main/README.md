# ToddlerGames
Interactive educational game to help toddlers learn numbers and astronomy. Designed to work on any device, on fullscreen mode. A touch screen is recommended but not required.

The site is written using JavaScript (ES6), SVG and CSS3 animations and gradients, using a fully vectorial design.

https://luis-m-gonzalez.github.io/ToddlerGames/
